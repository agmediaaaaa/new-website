"use client"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { motion } from "framer-motion"
import Script from "next/script"

export default function HeroSection() {
  return (
    <section className="hero-section">
      <div className="section-inner">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              className="text-xl md:text-2xl font-medium text-[#5538CF]"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.8 }}
            >
              FOR STAFFING FIRMS:
            </motion.div>
            <motion.h1
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="text-gray-900"
            >
              Get <span className="text-[#5538CF]">3-5 job</span> orders <span>a month using</span>{" "}
              <span>AI based cold emails</span>
            </motion.h1>
            <motion.div
              className="pt-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7, duration: 0.8 }}
            >
              <Link href="#learn-more">
                <Button className="primary-button">
                  LEARN MORE
                  <span className="ml-2">→</span>
                </Button>
              </Link>
            </motion.div>
          </motion.div>
          <motion.div
            className="relative rounded-xl overflow-hidden"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            <div className="wistia-container">
              <Script src="https://fast.wistia.com/player.js" strategy="afterInteractive" />
              <Script src="https://fast.wistia.com/embed/zuvms7wuaw.js" strategy="afterInteractive" type="module" />
              <div
                dangerouslySetInnerHTML={{
                  __html: `
                    <style>
                      wistia-player[media-id='zuvms7wuaw']:not(:defined) { 
                        background: center / contain no-repeat url('https://fast.wistia.com/embed/medias/zuvms7wuaw/swatch'); 
                        display: block; 
                        filter: blur(5px); 
                        padding-top:51.25%; 
                      }
                    </style>
                    <wistia-player media-id="zuvms7wuaw" aspect="1.951219512195122"></wistia-player>
                  `,
                }}
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
